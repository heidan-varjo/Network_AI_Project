﻿"""
Real-Time Packet-Level AI System - Dataset Generator
Generates 100,000+ synthetic network packets with realistic features
Author: Atri Pramanik (23BCE0200)
"""

import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import random

class PacketDatasetGenerator:
    def __init__(self, total_samples=100000, error_ratio=0.30, seed=42):
        """
        Initialize the packet dataset generator
        
        Args:
            total_samples: Total number of packets to generate
            error_ratio: Proportion of error packets (default 30%)
            seed: Random seed for reproducibility
        """
        self.total_samples = total_samples
        self.error_ratio = error_ratio
        np.random.seed(seed)
        random.seed(seed)
        
        # Protocol distributions
        self.protocols = {
            'TCP': 0.60,
            'UDP': 0.30,
            'ICMP': 0.10
        }
        
        # Error types for simulation
        self.error_types = [
            'bit_flip',
            'corruption',
            'timing_error',
            'burst_error',
            'noise_interference'
        ]
        
    def generate_ip_address(self):
        """Generate random valid IPv4 address"""
        return f"{random.randint(1, 255)}.{random.randint(0, 255)}." \
               f"{random.randint(0, 255)}.{random.randint(1, 255)}"
    
    def generate_protocol(self):
        """Generate protocol based on realistic distribution"""
        rand = random.random()
        if rand < 0.60:
            return 'TCP'
        elif rand < 0.90:
            return 'UDP'
        else:
            return 'ICMP'
    
    def generate_packet_size(self, protocol):
        """Generate realistic packet size based on protocol"""
        if protocol == 'TCP':
            # TCP packets typically larger
            return int(np.random.normal(800, 300))
        elif protocol == 'UDP':
            # UDP packets more varied
            return int(np.random.uniform(64, 1518))
        else:  # ICMP
            # ICMP packets typically small
            return int(np.random.normal(100, 30))
    
    def generate_latency(self, has_error):
        """Generate latency with realistic distribution"""
        if has_error:
            # Error packets tend to have higher latency
            return max(1.0, np.random.exponential(25))
        else:
            # Normal packets have lower latency
            return max(1.0, np.random.gamma(2, 5))
    
    def generate_queue_depth(self, has_error):
        """Generate queue depth (congestion indicator)"""
        if has_error:
            # Errors more common under congestion
            return int(np.random.uniform(40, 100))
        else:
            return int(np.random.uniform(0, 60))
    
    def generate_inter_arrival_time(self):
        """Generate realistic inter-arrival time between packets (ms)"""
        return max(0.1, np.random.exponential(5))
    
    def calculate_historical_error_rate(self, packet_index, packets_data):
        """Calculate historical error rate for recent packets"""
        if packet_index < 100:
            return 0.0
        
        # Look at last 100 packets
        recent_errors = packets_data['has_error'][max(0, packet_index-100):packet_index]
        return recent_errors.mean() if len(recent_errors) > 0 else 0.0
    
    def generate_dataset(self):
        """Generate complete dataset with all features"""
        print(f"Generating {self.total_samples} packet samples...")
        print(f"Error ratio: {self.error_ratio*100}%")
        
        # Determine which packets will have errors
        num_errors = int(self.total_samples * self.error_ratio)
        error_indices = set(random.sample(range(self.total_samples), num_errors))
        
        packets = []
        start_time = datetime.now()
        current_time = start_time
        
        for i in range(self.total_samples):
            has_error = i in error_indices
            protocol = self.generate_protocol()
            
            # Generate packet features
            packet = {
                'packet_id': i,
                'timestamp': current_time.timestamp(),
                'source_ip': self.generate_ip_address(),
                'dest_ip': self.generate_ip_address(),
                'source_port': random.randint(1024, 65535),
                'dest_port': random.randint(1, 65535),
                'protocol': protocol,
                'packet_size': self.generate_packet_size(protocol),
                'latency_ms': self.generate_latency(has_error),
                'queue_depth': self.generate_queue_depth(has_error),
                'inter_arrival_time': self.generate_inter_arrival_time(),
                'network_congestion': random.uniform(0, 1),
                'buffer_utilization': random.uniform(0, 1),
                'has_error': int(has_error),
                'error_type': random.choice(self.error_types) if has_error else 'none'
            }
            
            packets.append(packet)
            
            # Update timestamp
            current_time += timedelta(milliseconds=packet['inter_arrival_time'])
            
            # Progress indicator
            if (i + 1) % 10000 == 0:
                print(f"Generated {i + 1}/{self.total_samples} packets...")
        
        # Convert to DataFrame
        df = pd.DataFrame(packets)
        
        # Calculate historical error rate
        print("Calculating historical error rates...")
        df['historical_error_rate'] = [
            self.calculate_historical_error_rate(i, df) 
            for i in range(len(df))
        ]
        
        # Encode protocol as numeric
        protocol_mapping = {'TCP': 0, 'UDP': 1, 'ICMP': 2}
        df['protocol_encoded'] = df['protocol'].map(protocol_mapping)
        
        # Clip packet sizes to realistic Ethernet frame range
        df['packet_size'] = df['packet_size'].clip(64, 1518)
        
        # Add derived features
        df['size_latency_ratio'] = df['packet_size'] / (df['latency_ms'] + 1)
        df['congestion_score'] = (df['network_congestion'] + 
                                   df['buffer_utilization'] + 
                                   df['queue_depth']/100) / 3
        
        print(f"\nâœ“ Dataset generation complete!")
        print(f"Total packets: {len(df)}")
        print(f"Error packets: {df['has_error'].sum()} ({df['has_error'].mean()*100:.1f}%)")
        print(f"Normal packets: {(1-df['has_error']).sum()} ({(1-df['has_error'].mean())*100:.1f}%)")
        
        return df
    
    def save_dataset(self, df, train_ratio=0.70, val_ratio=0.15, test_ratio=0.15):
        """Split and save dataset into train/val/test sets"""
        print("\nSplitting dataset...")
        
        # Shuffle dataset
        df_shuffled = df.sample(frac=1, random_state=42).reset_index(drop=True)
        
        # Calculate split indices
        train_size = int(len(df_shuffled) * train_ratio)
        val_size = int(len(df_shuffled) * val_ratio)
        
        # Split data
        train_df = df_shuffled[:train_size]
        val_df = df_shuffled[train_size:train_size + val_size]
        test_df = df_shuffled[train_size + val_size:]
        
        # Save datasets
        train_df.to_csv('packet_data_train.csv', index=False)
        val_df.to_csv('packet_data_val.csv', index=False)
        test_df.to_csv('packet_data_test.csv', index=False)
        df_shuffled.to_csv('packet_data_full.csv', index=False)
        
        print(f"âœ“ Training set: {len(train_df)} samples â†’ packet_data_train.csv")
        print(f"âœ“ Validation set: {len(val_df)} samples â†’ packet_data_val.csv")
        print(f"âœ“ Test set: {len(test_df)} samples â†’ packet_data_test.csv")
        print(f"âœ“ Full dataset: {len(df_shuffled)} samples â†’ packet_data_full.csv")
        
        # Print statistics
        self.print_statistics(train_df, val_df, test_df)
        
        return train_df, val_df, test_df
    
    def print_statistics(self, train_df, val_df, test_df):
        """Print dataset statistics"""
        print("\n" + "="*60)
        print("DATASET STATISTICS")
        print("="*60)
        
        for name, df in [("Training", train_df), ("Validation", val_df), ("Test", test_df)]:
            print(f"\n{name} Set:")
            print(f"  Total packets: {len(df)}")
            print(f"  Error packets: {df['has_error'].sum()} ({df['has_error'].mean()*100:.1f}%)")
            print(f"  Protocol distribution:")
            print(f"    TCP: {(df['protocol']=='TCP').sum()} ({(df['protocol']=='TCP').mean()*100:.1f}%)")
            print(f"    UDP: {(df['protocol']=='UDP').sum()} ({(df['protocol']=='UDP').mean()*100:.1f}%)")
            print(f"    ICMP: {(df['protocol']=='ICMP').sum()} ({(df['protocol']=='ICMP').mean()*100:.1f}%)")
            print(f"  Avg packet size: {df['packet_size'].mean():.1f} bytes")
            print(f"  Avg latency: {df['latency_ms'].mean():.2f} ms")


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Generate synthetic packet dataset")
    parser.add_argument("--total_samples", "-n", type=int, default=100000,
                        help="Number of packets to generate (default: 100000)")
    parser.add_argument("--error_ratio", "-e", type=float, default=0.30,
                        help="Proportion of error packets (default: 0.30)")
    parser.add_argument("--seed", "-s", type=int, default=42, help="Random seed (default: 42)")
    args = parser.parse_args()

    print("="*60)
    print("REAL-TIME PACKET-LEVEL AI SYSTEM")
    print("Dataset Generation Module")
    print("="*60 + "\n")

    generator = PacketDatasetGenerator(
        total_samples=args.total_samples,
        error_ratio=args.error_ratio,
        seed=args.seed
    )

    df = generator.generate_dataset()
    train_df, val_df, test_df = generator.save_dataset(df)

    print("\n" + "="*60)
    print("✓ Dataset generation complete!")
    print("Files saved in current directory")
    print("="*60)
