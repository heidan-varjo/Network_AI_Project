﻿"""
Real-Time Packet-Level AI System - Neural Network Training
Trains the error prediction model with exact architecture from review
Author: Atri Pramanik (23BCE0200)
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import classification_report, confusion_matrix, roc_curve, auc, f1_score
from sklearn.utils import class_weight
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers, models, callbacks # type: ignore
import json
from datetime import datetime
import pickle

class NetworkErrorPredictor:
    def __init__(self):
        self.model = None
        self.scaler = StandardScaler()
        self.history = None
        self.feature_columns = [
            'packet_size', 'latency_ms', 'queue_depth', 'inter_arrival_time',
            'network_congestion', 'buffer_utilization', 'historical_error_rate',
            'protocol_encoded', 'source_port', 'dest_port',
            'size_latency_ratio', 'congestion_score'
        ]

    def load_data(self, train_path, val_path, test_path):
        print("Loading datasets...")
        self.train_df = pd.read_csv(train_path)
        self.val_df = pd.read_csv(val_path)
        self.test_df = pd.read_csv(test_path)

        print(f"✓ Training samples: {len(self.train_df)}")
        print(f"✓ Validation samples: {len(self.val_df)}")
        print(f"✓ Test samples: {len(self.test_df)}")

        self.X_train = self.train_df[self.feature_columns].values
        self.y_train = self.train_df['has_error'].astype(int).values
        self.X_val = self.val_df[self.feature_columns].values
        self.y_val = self.val_df['has_error'].astype(int).values
        self.X_test = self.test_df[self.feature_columns].values
        self.y_test = self.test_df['has_error'].astype(int).values

        print(f"\n✓ Feature matrix shape: {self.X_train.shape}")
        print(f"✓ Number of features: {len(self.feature_columns)}")

    def preprocess_data(self, impute_strategy='mean'):
        print("\nPreprocessing data...")

        for name, df in (('train', self.train_df), ('val', self.val_df), ('test', self.test_df)):
            if df[self.feature_columns].isnull().any().any():
                if impute_strategy == 'mean':
                    df[self.feature_columns] = df[self.feature_columns].fillna(df[self.feature_columns].mean())
                    print(f"  Imputed NaNs in {name} using column means.")
                else:
                    df[self.feature_columns] = df[self.feature_columns].fillna(0)
                    print(f"  Imputed NaNs in {name} with zeros.")

        self.X_train_scaled = self.scaler.fit_transform(self.X_train).astype('float32')
        self.X_val_scaled = self.scaler.transform(self.X_val).astype('float32')
        self.X_test_scaled = self.scaler.transform(self.X_test).astype('float32')

        print("✓ Features normalized using StandardScaler")

    def build_model(self, lr=1e-3):
        print("\nBuilding neural network model...")
        model = models.Sequential([
            layers.Input(shape=(len(self.feature_columns),)),
            layers.Dense(128, activation='relu'),
            layers.Dropout(0.3),
            layers.Dense(64, activation='relu'),
            layers.Dropout(0.3),
            layers.Dense(32, activation='relu'),
            layers.Dense(1, activation='sigmoid')
        ])

        model.compile(
            optimizer=keras.optimizers.Adam(learning_rate=lr),
            loss='binary_crossentropy',
            metrics=['accuracy', keras.metrics.Precision(), keras.metrics.Recall()]
        )
        model.summary()
        self.model = model

    def train_model(self, epochs=50, batch_size=32):
        print(f"\nTraining model for {epochs} epochs...")
        es = callbacks.EarlyStopping(monitor='val_loss', patience=5, restore_best_weights=True)
        rl = callbacks.ReduceLROnPlateau(monitor='val_loss', factor=0.5, patience=3, min_lr=1e-5)

        class_weights = class_weight.compute_class_weight(
            'balanced', classes=np.unique(self.y_train), y=self.y_train)
        cw = dict(enumerate(class_weights))

        self.history = self.model.fit(
            self.X_train_scaled, self.y_train,
            validation_data=(self.X_val_scaled, self.y_val),
            epochs=epochs, batch_size=batch_size,
            class_weight=cw, callbacks=[es, rl], verbose=1
        )

    def evaluate_model(self, threshold=0.5):
        print("\nEvaluating model...")
        y_pred_prob = self.model.predict(self.X_test_scaled).ravel()
        y_pred = (y_pred_prob > threshold).astype(int)

        print("\nClassification Report:")
        print(classification_report(self.y_test, y_pred, digits=4))

        cm = confusion_matrix(self.y_test, y_pred)
        tn, fp, fn, tp = cm.ravel()

        accuracy = (tp + tn) / (tp + tn + fp + fn)
        precision = tp / (tp + fp) if (tp + fp) > 0 else 0
        recall = tp / (tp + fn) if (tp + fn) > 0 else 0
        f1 = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0

        metrics = {
            'accuracy': float(accuracy),
            'precision': float(precision),
            'recall': float(recall),
            'f1_score': float(f1),
            'confusion_matrix': cm.tolist(),
            'timestamp': datetime.now().isoformat()
        }

        with open('model_metrics.json', 'w') as f:
            json.dump(metrics, f, indent=4)

        print("\n✓ Metrics saved to model_metrics.json")
        return metrics, y_pred, y_pred_prob

    # --- (your plotting & save_model functions remain unchanged) ---
    def plot_training_history(self):
        print("\nGenerating training history plots...")
        fig, axes = plt.subplots(2, 2, figsize=(15, 10))
        hist = self.history.history
        axes[0, 0].plot(hist['loss']); axes[0, 0].plot(hist['val_loss']); axes[0, 0].set_title('Loss')
        axes[0, 1].plot(hist['accuracy']); axes[0, 1].plot(hist['val_accuracy']); axes[0, 1].set_title('Accuracy')
        if 'precision' in hist: axes[1, 0].plot(hist['precision']); axes[1, 0].plot(hist['val_precision']); axes[1, 0].set_title('Precision')
        if 'recall' in hist: axes[1, 1].plot(hist['recall']); axes[1, 1].plot(hist['val_recall']); axes[1, 1].set_title('Recall')
        plt.tight_layout()
        plt.savefig('training_history.png', dpi=300)
        print("✓ training_history.png saved")
        plt.close()

    def plot_confusion_matrix(self, y_pred):
        cm = confusion_matrix(self.y_test, y_pred)
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=['Normal', 'Error'], yticklabels=['Normal', 'Error'])
        plt.title('Confusion Matrix'); plt.xlabel('Predicted'); plt.ylabel('True')
        plt.tight_layout(); plt.savefig('confusion_matrix.png', dpi=300); plt.close()
        print("✓ confusion_matrix.png saved")

    def plot_roc_curve(self, y_pred_prob):
        fpr, tpr, _ = roc_curve(self.y_test, y_pred_prob)
        roc_auc = auc(fpr, tpr)
        plt.plot(fpr, tpr, label=f"AUC = {roc_auc:.3f}")
        plt.plot([0, 1], [0, 1], 'k--')
        plt.title('ROC Curve'); plt.xlabel('FPR'); plt.ylabel('TPR')
        plt.legend(); plt.tight_layout(); plt.savefig('roc_curve.png', dpi=300); plt.close()
        print("✓ roc_curve.png saved")

    def save_model(self):
        print("\nSaving model...")
        self.model.save('network_error_model.h5')
        with open('scaler.pkl', 'wb') as f:
            pickle.dump(self.scaler, f)
        with open('feature_columns.json', 'w') as f:
            json.dump(self.feature_columns, f, indent=4)
        print("✓ Model, scaler, and feature columns saved.")


def main():
    print("="*60)
    print("REAL-TIME PACKET-LEVEL AI SYSTEM")
    print("Neural Network Training Module")
    print("="*60 + "\n")

    predictor = NetworkErrorPredictor()
    predictor.load_data('packet_data_train.csv', 'packet_data_val.csv', 'packet_data_test.csv')
    predictor.preprocess_data()
    predictor.build_model()
    predictor.train_model(epochs=3, batch_size=32)  # shorter run for testing
    metrics, y_pred, y_pred_prob = predictor.evaluate_model()
    predictor.plot_training_history()
    predictor.plot_confusion_matrix(y_pred)
    predictor.plot_roc_curve(y_pred_prob)
    predictor.save_model()

if __name__ == '__main__':
    main()
